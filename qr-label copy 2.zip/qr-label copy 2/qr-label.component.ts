import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as QRCode from 'qrcode';

@Component({
  selector: 'app-qr-label',
  templateUrl: './qr-label.component.html',
  styleUrls: ['./qr-label.component.scss'],
})
export class QrLabelComponent implements OnInit {
  qrForm!: FormGroup;
  qrCodeDataUrl!: string;

  @ViewChild('printSection') printSection!: ElementRef; // Reference to the print section

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.qrForm = this.fb.group({
      id: ['', Validators.required],
      name: ['', Validators.required],
      year: [''], // Optional field
    });
  }

  async generateQR(): Promise<void> {
    if (this.qrForm.valid) {
      const id = this.qrForm.value.id;

      // Generate the QR Code using the ID
      try {
        this.qrCodeDataUrl = await QRCode.toDataURL(id, { scale: 4 });

        // Set the QR code in the hidden print section and trigger print
        setTimeout(() => {
          this.triggerPrint();
        }, 500); // Small delay to ensure QR code is rendered
      } catch (err) {
        console.error('Error generating QR Code', err);
      }
    }
  }

  triggerPrint(): void {
    const printWindow = window.open('', '', 'width=400,height=400');
    const printContent = this.printSection.nativeElement.innerHTML;

    // Adding print-specific styles for the label size and layout
    const printStyles = `
      <style>
        @page {
          size: 2cm 4cm;  /* Set the print size */
          margin: 0;      /* No margin for label */
        }
              </style>
    `;

    // Write the content to the new print window
    printWindow?.document.write(`
      <html>
      <head>
        <title>Print Label</title>
        ${printStyles}
      </head>
      <body>
        ${printContent}
      </body>
      </html>
    `);

    printWindow?.document.close(); // Ensure the document is fully loaded
    printWindow?.focus(); // Set focus to the new print window

    printWindow?.print(); // Trigger the print dialog
    // printWindow?.onafterprint = () => printWindow?.close(); // Close the print window after printing
  }
}
