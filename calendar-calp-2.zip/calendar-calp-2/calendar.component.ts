import { Component, HostListener, Input, OnInit } from '@angular/core';
import { Car } from '../model/car.model';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
})
export class CalendarComponent implements OnInit {
  // Current month and year, initialized to today's month and year
  currentMonth: number = new Date().getMonth();
  currentYear: number = new Date().getFullYear();
  startYear: number = this.currentYear - 5; // Start year for displaying the year range in the popup
  selectedCar: Car | null = null;

  popupTop: number | null = null;
  popupLeft: number | null = null;
  popupPosition: 'top' | 'bottom' = 'top';

  // Car data (you can fetch this from a service in a real application)
  cars = [
    {
      carModel: 'BMW X5',
      bookings: [
        { bookedStartDate: '2024-12-01', bookingEndDate: '2024-12-05' },
        { bookedStartDate: '2024-11-01', bookingEndDate: '2024-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'MG Hector',
      bookings: [
        { bookedStartDate: '2025-01-01', bookingEndDate: '2025-01-05' },
        { bookedStartDate: '2025-03-01', bookingEndDate: '2025-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'BMW X5',
      bookings: [
        { bookedStartDate: '2024-12-01', bookingEndDate: '2024-12-05' },
        { bookedStartDate: '2024-11-01', bookingEndDate: '2024-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'MG Hector',
      bookings: [
        { bookedStartDate: '2025-01-01', bookingEndDate: '2025-01-05' },
        { bookedStartDate: '2025-03-01', bookingEndDate: '2025-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'BMW X5',
      bookings: [
        { bookedStartDate: '2024-12-01', bookingEndDate: '2024-12-05' },
        { bookedStartDate: '2024-11-01', bookingEndDate: '2024-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'MG Hector',
      bookings: [
        { bookedStartDate: '2025-01-01', bookingEndDate: '2025-01-05' },
        { bookedStartDate: '2025-03-01', bookingEndDate: '2025-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'BMW X5',
      bookings: [
        { bookedStartDate: '2024-12-01', bookingEndDate: '2024-12-05' },
        { bookedStartDate: '2024-11-01', bookingEndDate: '2024-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
    {
      carModel: 'MG Hector',
      bookings: [
        { bookedStartDate: '2025-01-01', bookingEndDate: '2025-01-05' },
        { bookedStartDate: '2025-03-01', bookingEndDate: '2025-11-15' },
      ],
      imageUrl: 'https://www.w3schools.com/images/w3schools_green.jpg',
    },
  ];

  dayNames: string[] = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa']; // German day names
  // Array of month names
  monthNames: string[] = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  // Toggle variable to show/hide the month selection popup
  showMonthPopup: boolean = false;

  // Boolean to track whether the year selection is active
  isYearSelection: boolean = false;
  // Array to store days in the current month (this can be updated based on your logic)
  daysInMonth: any[] = [];

  constructor() {}

  ngOnInit() {
    this.generateDaysInMonth();
  }

  // Toggle the visibility of the month popup
  toggleMonthPopup(event: MouseEvent, position: string): void {
    this.showMonthPopup = !this.showMonthPopup;

    if (this.showMonthPopup) {
      const target = event.target as HTMLElement;
      const rect = target.getBoundingClientRect(); // Get the position of the clicked header

      if (position === 'top') {
        // Set position relative to the top header
        this.popupTop = rect.bottom + window.scrollY; // Adjusting position dynamically
      } else if (position === 'bottom') {
        // Set position relative to the bottom header
        this.popupTop = rect.top + window.scrollY - 300; // Adjust as needed based on popup height
      }

      // You may also want to calculate left/right position, but your popup is centered in this case
      this.popupLeft = rect.left;
    } else {
      this.popupTop = null;
      this.popupLeft = null;
    }
  }

  // Navigate to the previous year (in the popup)
  previousYearRange(): void {
    this.startYear -= 12; // Move the year range back by 12 years
  }

  // Navigate to the next year (in the popup)
  nextYearRange(): void {
    this.startYear += 12; // Move the year range forward by 12 years
  }

  // Select a month from the popup
  selectMonth(monthIndex: number): void {
    this.currentMonth = monthIndex; // Update the current month to the selected one
    this.generateDaysInMonth(); // Refresh the calendar based on the new month
    this.showMonthPopup = false; // Close the popup after selection
  }

  // Switch to year selection in the popup
  showYearSelection(): void {
    this.isYearSelection = true; // Activate year selection
  }

  // Select a year from the year list
  selectYear(year: number): void {
    this.currentYear = year; // Update the current year
    this.isYearSelection = false; // Return to month selection after choosing the year
  }

  // Generates the days in the current month
  generateDaysInMonth() {
    const daysInMonth = new Date(
      this.currentYear,
      this.currentMonth + 1,
      0
    ).getDate();
    const firstDayOfMonth = new Date(
      this.currentYear,
      this.currentMonth,
      1
    ).getDay();
    this.daysInMonth = [];

    // Loop through the days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayOfWeek = new Date(
        this.currentYear,
        this.currentMonth,
        i
      ).getDay();
      this.daysInMonth.push({
        date: i,
        day: dayOfWeek,
      });
    }
  }

  // Navigate to the next month
  nextMonth() {
    if (this.currentMonth === 11) {
      this.currentMonth = 0;
      this.currentYear++;
    } else {
      this.currentMonth++;
    }
    this.generateDaysInMonth();
  }

  // Navigate to the previous month
  previousMonth() {
    if (this.currentMonth === 0) {
      this.currentMonth = 11;
      this.currentYear--;
    } else {
      this.currentMonth--;
    }
    this.generateDaysInMonth();
  }

  // Check if the car is unavailable for the given date
  isUnavailable(car: any, date: number): boolean {
    for (let booking of car.bookings) {
      // Normalize the dates to remove time component
      const startDate = new Date(booking.bookedStartDate);
      startDate.setHours(0, 0, 0, 0); // Reset time to 00:00:00

      const endDate = new Date(booking.bookingEndDate);
      endDate.setHours(23, 59, 59, 999); // Set time to the end of the day

      const current = new Date(this.currentYear, this.currentMonth, date);
      current.setHours(0, 0, 0, 0); // Reset time to 00:00:00

      if (current >= startDate && current <= endDate) {
        return true;
      }
    }
    return false;
  }

  selectedImage: string | null = null;

  showImage(imageUrl: string): void {
    this.selectedImage = imageUrl;
  }

  closeImage(): void {
    this.selectedImage = null;
  }

  // Method to log the car model when the edit button is clicked
  logCarModel(carModel: string): void {
    console.log(`Car Model: ${carModel}`);
  }

  // Get the number of days in the current month
  getDaysInMonth(month: number, year: number): number {
    return new Date(year, month + 1, 0).getDate();
  }
  // Method to dynamically calculate day width based on number of days
  getDynamicDayWidth(): string {
    const daysInMonth = this.getDaysInMonth(
      this.currentMonth,
      this.currentYear
    );

    // Example: if there are 31 days, make the width smaller, and increase it for months with fewer days
    if (daysInMonth === 28) {
      return 'calc(100% / 28)';
    } else if (daysInMonth === 29) {
      return 'calc(100% / 29)';
    } else if (daysInMonth === 30) {
      return 'calc(100% / 30)';
    } else {
      return 'calc(100% / 31)';
    }
  }

  // Close the popup if clicking outside
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event): void {
    const target = event.target as HTMLElement;
    if (
      !target.closest('.calendar-header') &&
      !target.closest('.month-popup')
    ) {
      this.showMonthPopup = false; // Close the popup if clicking outside
    }
  }

  // Show tooltip for the selected car
  showTooltip(car: Car): void {
    this.selectedCar = car;
  }

  // Hide tooltip
  hideTooltip(): void {
    this.selectedCar = null;
  }

  // Navigate to the booked start date's month
  navigateToMonth(startDate: string | undefined): void {
    if (startDate) {
      // Ensure the startDate is defined
      const date = new Date(startDate);
      this.currentMonth = date.getMonth();
      this.currentYear = date.getFullYear();
      this.generateDaysInMonth();
    }
  }
}
