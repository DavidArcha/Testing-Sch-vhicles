import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as QRCode from 'qrcode';

@Component({
  selector: 'app-qr-label',
  templateUrl: './qr-label.component.html',
  styleUrls: ['./qr-label.component.scss'],
})
export class QrLabelComponent implements OnInit {
  qrForm!: FormGroup;
  qrCodeDataUrl!: string;

  @ViewChild('printSection') printSection!: ElementRef; // Reference to the print section

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.qrForm = this.fb.group({
      id: ['', Validators.required],
      name: ['', Validators.required],
      year: [''], // Optional field
    });
  }

  // async generateQR(): Promise<void> {
  //   if (this.qrForm.valid) {
  //     const id = this.qrForm.value.id;

  //     // Generate the QR Code using the ID
  //     try {
  //       this.qrCodeDataUrl = await QRCode.toDataURL(id, { scale: 4 });

  //       // Set the QR code in the hidden print section and trigger print
  //       setTimeout(() => {
  //         this.triggerPrint();
  //       }, 500); // Small delay to ensure QR code is rendered
  //     } catch (err) {
  //       console.error('Error generating QR Code', err);
  //     }
  //   }
  // }

  async generateQR(): Promise<void> {
    if (this.qrForm.valid) {
      const id = this.qrForm.value.id;

      // Generate the QR Code using the ID
      try {
        this.qrCodeDataUrl = await QRCode.toDataURL(id, { scale: 4 });

        // Ensure QR code is generated before triggering print window
        if (this.qrCodeDataUrl) {
          setTimeout(() => {
            this.triggerPrint(); // Trigger the print only after a delay to ensure QR code is ready
          }, 1000); // 300ms delay to ensure QR code is fully rendered
        } else {
          console.error('Failed to generate QR code');
        }
      } catch (err) {
        console.error('Error generating QR Code', err);
      }
    }
  }

  triggerPrint(): void {
    const printWindow = window.open('', '', 'width=600,height=400');
    const printContent = this.printSection.nativeElement.innerHTML;
  
    const printStyles = `
      <style>
        @page {
          size: 2cm 4cm !important;  /* Enforce label print size */
          margin: 0;
        }
      </style>
    `;
  
    if (printWindow) {
      printWindow.document.write(`
        <html>
        <head>
          <title>Print Label</title>
          ${printStyles}
        </head>
        <body>
          <div class="label-container">
            ${printContent}
          </div>
        </body>
        </html>
      `);
  
      printWindow.document.close();
      printWindow.focus();
  
      printWindow.print();
  
      printWindow.onafterprint = () => {
        printWindow.close();
      };
  
      setTimeout(() => {
        if (!printWindow.closed) {
          printWindow.close();
        }
      }, 1000);
    }
  }
  
}
